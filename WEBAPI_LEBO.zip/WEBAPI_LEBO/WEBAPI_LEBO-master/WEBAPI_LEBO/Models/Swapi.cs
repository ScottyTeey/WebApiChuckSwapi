﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEBAPI_LEBO.Models
{
    public class Swapi
    {
        public int id { get; set; }

        public int name { get; set; }
    }
}
